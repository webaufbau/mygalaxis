<?php

return [
    'welcomeUser'           => 'Willkommen, %s!',
    'user'                  => 'Nutzer',
    'status'                => 'Status',
    'active'                => 'Aktiv',
    'inactive'              => 'Inaktiv',
    'automaticPurchaseInfo' => 'Um keine Anfragen mehr zu verpassen, kannst du in deinem',
    'profile'               => 'Profil',
    'automaticPurchaseOption'=> 'die Option <strong>„automatisch kaufen“</strong> aktivieren.',
    'purchasedOffers'       => 'Gekaufte Angebote',
    'noOffers'              => 'Du hast noch keine Angebote gekauft.',
    'purchaseDate'          => 'Kaufdatum',
];
