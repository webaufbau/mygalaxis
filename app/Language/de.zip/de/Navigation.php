<?php
return [
    'overview' => 'Übersicht',
    'filter' => 'Filter',
    'requests' => 'Anfragen',
    'openRequests' => 'Offene Anfragen',
    'purchasedRequests' => 'Gekaufte Anfragen',
    'finance' => 'Finanzen',
    'agenda' => 'Agenda',
    'myAccount' => 'Mein Konto',
    'reviews' => 'Bewertungen',
    'toggleNavigation' => 'Navigation umschalten',
    'logout' => 'Abmelden',
];
