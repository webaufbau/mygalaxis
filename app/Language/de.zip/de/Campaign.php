<?php
return [
    'status' => [
        'pending'   => 'Offen',
        'sent'      => 'Gesendet',
        'responded' => 'Geantwortet',
        'error'     => 'Fehler',
    ],
];
